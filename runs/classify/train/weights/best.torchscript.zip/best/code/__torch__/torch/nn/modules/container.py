class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.ultralytics.nn.modules.conv.Conv
  __annotations__["1"] = __torch__.ultralytics.nn.modules.conv.___torch_mangle_2.Conv
  __annotations__["2"] = __torch__.ultralytics.nn.modules.block.C2f
  __annotations__["3"] = __torch__.ultralytics.nn.modules.conv.___torch_mangle_17.Conv
  __annotations__["4"] = __torch__.ultralytics.nn.modules.block.___torch_mangle_39.C2f
  __annotations__["5"] = __torch__.ultralytics.nn.modules.conv.___torch_mangle_42.Conv
  __annotations__["6"] = __torch__.ultralytics.nn.modules.block.___torch_mangle_64.C2f
  __annotations__["7"] = __torch__.ultralytics.nn.modules.conv.___torch_mangle_67.Conv
  __annotations__["8"] = __torch__.ultralytics.nn.modules.block.___torch_mangle_82.C2f
  __annotations__["9"] = __torch__.ultralytics.nn.modules.head.Classify
class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.ultralytics.nn.modules.block.Bottleneck
