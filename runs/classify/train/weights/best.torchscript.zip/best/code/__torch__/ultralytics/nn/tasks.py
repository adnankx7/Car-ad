class ClassificationModel(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  model : __torch__.torch.nn.modules.container.Sequential
  def forward(self: __torch__.ultralytics.nn.tasks.ClassificationModel,
    x: Tensor) -> Tensor:
    model = self.model
    _9 = getattr(model, "9")
    model0 = self.model
    _8 = getattr(model0, "8")
    model1 = self.model
    _7 = getattr(model1, "7")
    model2 = self.model
    _6 = getattr(model2, "6")
    model3 = self.model
    _5 = getattr(model3, "5")
    model4 = self.model
    _4 = getattr(model4, "4")
    model5 = self.model
    _3 = getattr(model5, "3")
    model6 = self.model
    _2 = getattr(model6, "2")
    model7 = self.model
    _1 = getattr(model7, "1")
    model8 = self.model
    _90 = getattr(model8, "9")
    conv = _90.conv
    act = conv.act
    model9 = self.model
    _0 = getattr(model9, "0")
    _10 = (_1).forward(act, (_0).forward(act, x, ), )
    _11 = (_3).forward(act, (_2).forward(act, _10, ), )
    _12 = (_5).forward(act, (_4).forward(act, _11, ), )
    _13 = (_7).forward(act, (_6).forward(act, _12, ), )
    _14 = (_9).forward((_8).forward(act, _13, ), )
    return _14
